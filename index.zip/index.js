// document.querySelector('.whatsapp-button').addEventListener('click', function () {
//     console.log('WhatsApp button clicked');
// });



const twilio = require("twilio");
const accountSid = ACf80baa5e7daf9f6fd79974dc2158b662;
const authToken = e7ba424f19fc978e7d6b785097a3a97c;
const client = twilio(accountSid, authToken);

async function createMessage() {
    const message = await client.messages.create({
        body: "Hello, there!",
        from: "whatsapp:+14155238886",
        to: "whatsapp:+916299079512",
    });

    console.log(message.body);
}

createMessage();